package code;

public class Developer {
	private static Developer developer;
	private Developer(){
		
	}
	public static Developer getDeveloper(){
		if(developer == null){
			synchronized(Developer.class){
				if(developer == null){
					developer = new Developer();
				}
			}
		}
		return developer;
	}
	
	public static String getName(){
		return "Author:Zhu Pengfei��Li Cairui";
	}
	
}
