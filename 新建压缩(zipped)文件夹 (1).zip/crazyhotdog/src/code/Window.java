package code;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Window extends JFrame{
	private JTextField t3;
	private JButton b1;
	private JButton b2;
	boolean ifSee = true;
	public static int highscore;
	Developer developer = Developer.getDeveloper();
	
	Window(){
		super("��Ϸ����");
		setBounds((200+Table.width/2),Table.height/4,200,200);
		setVisible(ifSee);
		
		b1 = new JButton("��");
		b2 = new JButton("�˳�");
		b1.setBounds(31,13,13,13);
		b2.setBounds(31, 13, 13, 13);
		
		t3 = new JTextField("��߷�:"+highscore);
		t3.setEnabled(false);
		
		Container c1 = getContentPane();
		c1.setLayout(new FlowLayout());
		c1.add(new JLabel("���¿�ʼ��"));
		c1.add(b1);
		c1.add(b2);
		c1.add(t3);
		c1.add(new JLabel(developer.getName()));
		addListener();
	}
	
	private void addListener(){
		b1.addActionListener(new ActionListener(){
			
			@Override
			public void actionPerformed(ActionEvent e){
				Game.replay = true;
				dispose();
			}
		});
		
		b2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
	}
}
